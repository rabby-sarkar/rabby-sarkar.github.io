
  Performance statistics for DSP solver: icalls =      1

 ===========================
 = multifrontal statistics =
 ===========================

     number of equations                     =            3240
     no. of nonzeroes in lower triangle of a =          178362
     no. of nonzeroes in the factor l        =          570228
     ratio of nonzeroes in factor (min/max)  =          0.8156
     number of super nodes                   =              90
     maximum order of a front matrix         =             348
     maximum size of a front matrix          =           60726
     maximum size of a front trapezoid       =           34620
     no. of floating point ops for factor    =      9.9142D+07
     no. of floating point ops for solve     =      2.0808D+06
     ratio of flops for factor (min/max)     =          0.6339
     ratio of allocated memory (max/min)     =          1.3012
     negative pivot monitoring activated
     number of negative pivots encountered   =               0
     factorization panel size                =             128
     number of processes used                =               4
     number of threads per process used      =               1
     number of cores used                    =               4
     time (cpu & wall) for structure input   =        0.000000        0.000495
     time (cpu & wall) for ordering          =        0.000000        0.005551
     time (cpu & wall) for other matrix prep =        0.000000        0.001571
     time (cpu & wall) for value input       =        0.000000        0.001939
     time (cpu & wall) for matrix distrib.   =        0.000000        0.010809
     time (cpu & wall) for numeric factor    =        0.015625        0.019725
     computational rate (gflops) for factor  =        6.345109        5.026253

     no input or output performed

  Solver Memory allocated on core    0       =        3.797 MB
  Solver Memory allocated on core    1       =        3.204 MB
  Solver Memory allocated on core    2       =        3.472 MB
  Solver Memory allocated on core    3       =        2.918 MB
  Total Solver Memory allocated by all cores =       13.392 MB

